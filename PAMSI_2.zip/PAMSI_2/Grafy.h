#pragma once
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <chrono>
using namespace std;


/*! \file Grafy.h
zawiera wszsytkie podstawowe struktury grafów
*/


/*! \brief klasa wierzcholek
 * Jest to podstawowy element listy wierzcholkow i obiektu krawedz
 *  zawiera Wartosc int, oraz wskaznik na nastepny obiekt
 */
class Wierzcholek
{
    public:
    int Wierz;
    Wierzcholek *nastepny;

    /*! \brief konstruktor bezparam klasy wierzcholek
     */
    Wierzcholek()
    {
        Wierz=0;
    }

    /*! \brief przeciazony operator << dla obiektu wierzcholek
     */
    friend ostream & operator << (ostream &wyj, const Wierzcholek &W)
    {
        return wyj<<W.Wierz;
    }
    /*! \brief przeciazony operator >> dla obiektu wierzcholek
     */
           friend istream & operator>> (istream &wej,  Wierzcholek &W)
    {
        wej>>W.Wierz;
        return wej;
    }
};


/*! \brief klasa Krawedz
 * Jest to podstawowy element listy listy krawedzi
 *  zawiera Dwa obiekty Wierzcholek i wartosc int informujacy o wadze krawedzi
 * oraz wskaznik na nastepny element listy
 */

class Krawedz
{
    public:
    Wierzcholek Poczatek;
    Wierzcholek Koniec;
    int Waga;
    Krawedz * Nastepna;

    /*! \brief konstruktor bezparam Ob. Krawedz
     */
        Krawedz()
    {
        Poczatek.Wierz=0;
        Koniec.Wierz=0;
        Waga=0;
    }


        ///Przeciazenie operatora <<
        friend ostream & operator << (ostream &wyj, const Krawedz &K)
    {
        return wyj/*<<"P K W\n"*/<<K.Poczatek<<" "<<K.Koniec<<" "<<K.Waga<<endl;
    }

        ///Przeciazenie operatora >>
         friend istream & operator >> (istream &wej,  Krawedz &K)
    {
        wej>>K.Poczatek;
        wej>>K.Koniec;
        wej>>K.Waga;
        return wej;
    }
};


/*! \brief klasa Lista Krawedzi
 * Obiekt ktory przechowuje wszystkie informacje o grafie
 *  zawiera lsite krawedzi grafu, a także informacje o liczbie wierzcholku, krawedzi i
 * o wierz. startowym
 */
class ListaKrawedzi
{
public:
    int Licznik=0;
    public:
    Krawedz *Glowa;
    Krawedz *Ogon;
//    void DodajGlowe(ifstream &plik);
   // void DodajGlowe();
     int startowy;
     int LKrawedzi;
     int LWierzcholkow;
     ///Konstruktor bezparam Listy Krawedzi
    ListaKrawedzi();


    /*! \brief konstruktor param Listy Krawedzi
 * Przyjmuje wartosc int, pozwala wczytywac dane z konsoli
 *
 */
    ListaKrawedzi(int LiczbaKrawedzi)
        {

            for (int i =0; i<LiczbaKrawedzi; ++i )
                DodajGlowe();
        }


         /*! \brief konstruktor param Listy Krawedzi
 * Przyjmuje wartosc ifstream, pozwala wczytywac dane z pliku
 *
 */
     ListaKrawedzi(ifstream &wej)
        {
            /*for(int i =0; i<3; ++i)
                {wej>>tab[i]; cout<<tab[i]<<" ";}       //testy dzialania
                startowy=tab[2];
                cout<<endl;*/


            wej>>LKrawedzi;
            wej>>LWierzcholkow;
            wej>>startowy;
            for (int i =0; i<LKrawedzi; ++i )
                DodajGlowe(wej);
        }

 /*! \brief funckja wypisujaca Liste Krawezdi
 * typ void, nie przyjmuje wartosci
 *
 */
void WypiszListeKrawedzi()
                {
                    cout<<LKrawedzi<<" " <<LWierzcholkow<<" "<<startowy<<endl;
                    Krawedz *Kra=Glowa;
                    for(int i=0; i<Licznik; ++i)
                    {
                        cout<<*Kra;
                        Kra=Kra->Nastepna;
                    }
                }

 /*! \brief funckja Dodaj Glowe, dla Listy Krawezdi
 * przyjmuje ifstream, typ void
 *	dodaje glowe przy wykorzystaniu danych z pliku
 */
void DodajGlowe(ifstream &plik)
    {

        Krawedz * Kr = new Krawedz();
        plik>>*Kr;
        Kr->Nastepna=Glowa;
        Glowa=Kr;

        if(Licznik==0)
            Ogon=Glowa;
        Licznik++;
    }

 /*! \brief funckja Dodaj Glowe, dla Listy Krawezdi
 * nic nie przyjmuje, typ void
 *	dodaje glowe przy wykorzystaniu danych ze standardowego wejscia
 */
 void DodajGlowe()
    {

        Krawedz * Kr = new Krawedz();
        cin>>*Kr;
        Kr->Nastepna= Glowa;
        Glowa=Kr;

        if(Licznik==0)
            Ogon=Glowa;

        Licznik++;
    }
};



///



//////////////////////////////////////////////////////////////////////

 /*! \brief Klasa Lista Sasiedztwa
 * Podstawowa struktura ListySasiedzwa
 *
 */
class ListaSasiedztwa
{   public:
    int Wierz;
    int Waga;

    ListaSasiedztwa * Nast;
 };




