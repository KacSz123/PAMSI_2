#pragma once
#include "Grafy.h"
using namespace std;

 /*! \brief PokazNajkSciezke
 * przyjmuje dwie wartosci *int i jeden int, typ void
 *	funkcja wypisuje najmniej kosztowna sciezke (wszystkie odwiedzone wierzcholkki) 
 * miedzy dwoma wybranymi wierzcholkami Grafu
 */
void PokazNajkSciezke(int*KosztDrogi, int * Poprzedni, int LWierzch);



 /*! \brief funckja Tworzy Macierz Sasiedztwa
 * przyjmuje *ListaKrawedzi i **int, typ void
 * Tworzy z argumentu **int macierz sasiedztwa
 *
 */
void StworzMacierzSasiedztwa(ListaKrawedzi *LK, int ** macierz );

 /*! \brief funckja Bellman_FordMacierzSasiedztwa
 * przyjmuje **int oraz *ListaKrawedzi, typ void
 * Wyszukuje najkrotsze drogi do wszystkich wierzcholkow z wierzcholka poczatkowego
 * na bazie Macierzy Sasiedztwa
 */
void Bellman_FordMacierzSasiedztwa(int **Macierz, ListaKrawedzi *LK);


 /*! \brief funckja PokazMacierz
 * przyjmuje **int oraz int, typ void
 * Wyswietla Macierz Sasiedztwa 
 */
void PokazMacierz(int ** macierz, int wierz);



 /*! \brief funckja StworzListeSasiedztwa
 * przyjmuje **ListaSasiedztwa, *ListaKrawedzi oraz *ListaSasiedztwa,  typ void
 * Tworzy liste  sasiedztwa 
 */
void StworzListeSasiedztwa(ListaSasiedztwa** TabList, ListaKrawedzi *LK, ListaSasiedztwa * L);


 /*! \brief funckja PokazMacierz
 * przyjmuje **int oraz int, typ void
 * Wyswietla Liste Sasiedztwa 
 */
void WyswietlListeSasiedztwa(ListaSasiedztwa ** TabList, int Wie);

 /*! \brief funckja Bellman_FordListaSasiedztwa
 * przyjmuje *ListaKrawedzi,  oraz **ListaSasiedztwa, typ void
 * Wyszukuje najkrotsze drogi do wszystkich wierzcholkow z wierzcholka poczatkowego
 * na bazie Listy Sasiedztwa
 */
void Bellman_FordListaSasiedztwa(ListaKrawedzi *LK, ListaSasiedztwa ** tabList);

