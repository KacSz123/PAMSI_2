
#pragma once
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <chrono>
using namespace std;




 /*! \brief WypiszDaneDoPliku
 * przyjmuje dwa arg. typu int i typ ofstream, typ void
 *	Wypisuje do pliku liczbe krawedzi, liczbe wierzcholkow i wierzcholek startowy
 */
void WypiszDaneDoPliku(int LiczbaWierzcholkow, int LiczbaKrawedzi, ofstream & plik);

 /*! \brief GenerujDaneGrafow
 * przyjmuje ofstream, typ void
 *	Generuje odpowiednia pule danych i przekazuje do wypisania funkcji WypiszDaneDopliku
 */
void GenerujDaneGrafow(ofstream& plik);
