//#pragma once
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <chrono>
#include "testy.h"
using namespace std;
/*! \file main.cpp
 * wykonuje glowny test.
 */


int main()
{
///Generowanie Danych
        srand(time(NULL));ofstream dane;
        cout<<"generuje dane\n";
        GenerujDaneGrafow(dane);
        cout<<"dane wygenerowane";
///


////glowny test grafowy
    cout<<"start\n";
    TestGlowny();
    cout<<"stop\n";
////
/////TestyPomocnicze();

    return 0;
}
