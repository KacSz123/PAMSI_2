
#include "testy.h"



    void TestGlowny()
    {
                ifstream dane1;
                dane1.open("gen_dane.txt", ios_base::in);
                ofstream WynikiWszystkie;
                WynikiWszystkie.open("wynWszystkie.txt");
                ofstream WynikiSprawozdanie;
                WynikiSprawozdanie.open("WynikiSpraw.txt");
    int TabLiczbWierzcholkow[5]={10, 50, 100, 150, 300};
    int TabGestosci[4]={25, 50, 75, 100};

    for(int l=0; l<5; ++l)
    {
        for(int i=0; i<4; i++)
        {
            double SumaListy=0,  SumaMacierzy=0;

            for(int j=0; j<100; ++j)
            {

                double CzasListy, CzasMacierzy;

                ListaKrawedzi  * LK= new ListaKrawedzi(dane1);
                ListaSasiedztwa **TLS = new ListaSasiedztwa *[LK->LKrawedzi];
                ListaSasiedztwa *LS;

            StworzListeSasiedztwa(TLS, LK, LS);
            auto czas_start1 = std::chrono::high_resolution_clock::now(); //start zegara
            Bellman_FordListaSasiedztwa(LK, TLS );
            auto czas_end1 = std::chrono::high_resolution_clock::now();
            CzasListy=(std::chrono::duration<double, std::milli>(czas_end1 - czas_start1).count());
            WynikiWszystkie<<"Jeden czas dla alg BF grafu na liscie o "<<TabLiczbWierzcholkow[l]<<" wierz i "<<TabGestosci[i]<<" gestosci :";
            WynikiWszystkie<<CzasListy;
            SumaListy+=CzasListy;

            delete [] TLS;
            delete []LS;


            int **macierz;
            macierz=new int *[LK->LWierzcholkow];
                for(int i=0; i<LK->LWierzcholkow; i++)
                    macierz[i]=new int [LK->LWierzcholkow];
            StworzMacierzSasiedztwa(LK, macierz);
            auto czas_start2 = std::chrono::high_resolution_clock::now(); //start zegara
            Bellman_FordMacierzSasiedztwa( macierz, LK);
            auto czas_end2 = std::chrono::high_resolution_clock::now();
            CzasMacierzy=(std::chrono::duration<double, std::milli>(czas_end2 - czas_start2).count());

            WynikiWszystkie<<"Jeden czas dla alg BF grafu na macierzy o "<<TabLiczbWierzcholkow[l]<<" wierz i "<<TabGestosci[i]<<" gestosci :";
            WynikiWszystkie<<CzasMacierzy<<endl;
            SumaMacierzy+=CzasMacierzy;
            delete [] macierz;
             delete []LK;
            }
           /* cout<<endl<<"Srednia czasow:"<<endl;
            cout<<SumaListy/100<<endl;
            cout<<endl<<"Srednia czasow:"<<endl;
            cout<<SumaMacierzy/100<<endl;*/

            WynikiSprawozdanie<<endl<<"Srednia czasow dla grafu na liscie o "<<TabLiczbWierzcholkow[l]<<" wierz i "<<TabGestosci[i]<<" gestosci"<<endl;
            WynikiSprawozdanie<<SumaListy/100<<endl;
            WynikiSprawozdanie<<endl<<"srednia czasow dla grafu na macierzy o "<<TabLiczbWierzcholkow[l]<<" wierz i "<<TabGestosci[i]<<" gestosci"<<endl;
            WynikiSprawozdanie<<SumaMacierzy/100<<endl;


         }
    }
        dane1.close();
        WynikiSprawozdanie.close();
        WynikiWszystkie.close();
    }



    void TestyPomocnicze()
{


    /*   ifstream dane1;
    dane1.open("gen_dane.txt", ios_base::in);
   ListaKrawedzi *LK = new ListaKrawedzi(dane1);*/

 /*
    cout<<"generowanie danych"<<endl;
    cout << "Hello world!" << endl;
    Krawedz<int> K, K2;
    cin>> K;
    cin>>K2;
    cout<<K<<K2;

    ;*/
    /*ListaKrawedzi  * LK= new ListaKrawedzi(2);

    cout<<"Waga glowy: "<<LK->Glowa->Waga<<endl;
    //cout<<&LK->Glowa;
    cout<<"wypisz Licznik: "<<LK->Licznik<<"\n";
    cout<<"wypisz\n";
    LK->WypiszListeKrawedzi();*/


/*
    ifstream dane1;
    dane1.open("gen_dane.txt", ios_base::in);



    cout<<"ListaKrawedzi \n";
    ListaKrawedzi  * LK= new ListaKrawedzi(dane1);
  //  cout<<*LK->Glowa;

  cout<<"start\n";
   LK->WypiszListeKrawedzi();
  cout<<"!!!!!!!!!!!!!!!!!!!!!!! LS!!!!"<<endl;

    ListaSasiedztwa **TLS = new ListaSasiedztwa *[LK->LKrawedzi];
    ListaSasiedztwa *LS;
    StworzListeSasiedztwa(TLS, LK, LS);

    macierz=new int *[LK->LWierzcholkow];
    for(int i=0; i<LK->LWierzcholkow; i++)
        macierz[i]=new int [LK->LWierzcholkow];
    cout<<"!!!!!!!!!!!!!!!!!!!!!!! LS!!!!"<<endl;
    WyswietlListeSasiedztwa(TLS, LK->LWierzcholkow);
    Bellman_FordListaSasiedztwa(LK, TLS );
    StworzMacierzSasiedztwa(LK, macierz);
    Bellman_FordMacierzSasiedztwa( macierz, LK);
    delete LS;
    delete[] TLS;*/

}
