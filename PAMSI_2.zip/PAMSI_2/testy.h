#pragma once
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <chrono>
#include "GenDane.h"
#include "Grafy.h"
#include "BF.h"
using namespace std;
/*! \file testy.h
 * zawiera testy algorymtu BF
 */




/*! \brief Testy glowny znajduje najkrotsza droge do
 * wszystkich pozostalych wierzcholkow w grafie, zlicza czas
 typ void*/
void TestGlowny();


/// testy pomocnicze działania poszczególnych elementów programu
void TestyPomocnicze();
