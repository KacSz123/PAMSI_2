#include "BF.h"


void PokazNajkSciezke(int*KosztDrogi, int * Poprzedni, int LWierzch)
{
    int * PokazSciezke=new int [LWierzch];
    int k=0, l;
    cout<<"Do: Droga\n";
    for(int i=0; i<LWierzch; ++i)
    {
        cout<<" "<<i<<":   ";


        for(l=i; l!=-1 && k<LWierzch; l = Poprzedni[l] )
           {
               PokazSciezke[k]=l;            // cout<<PokazSciezke[k];  /*cout<<l<<"L"; sprawdzenie dzialania */
               k++;
            }

        while(k) cout<<PokazSciezke[--k]<<" ";

        cout<<"Koszt: "<<KosztDrogi[i]<<endl;
    }
delete [] PokazSciezke;
}



/////

void StworzMacierzSasiedztwa(ListaKrawedzi *LK, int ** macierz )
{      /* cout<<"LKRAW:"<<LK->LKrawedzi;
        cout<<"\n LK DO MACIERZY:\n";
        LK->WypiszListeKrawedzi();
        cout<<"GLOWA LK\n";
        cout<<LK->Glowa->Poczatek.Wierz<<" "<<LK->Glowa->Koniec.Wierz<<" "<<LK->Glowa->Waga<<endl;
    */
    int *TabPom=new int [3];
    int k=0;

    for(int i=0; i<LK->LWierzcholkow; ++i)
    {
        for(int j=k; j<LK->LWierzcholkow; ++j)
        {
            macierz[i][j]=0;
            macierz[j][i]=0;
        }
        k++;
    }
    Krawedz *Kpom= new Krawedz;
    Kpom=LK->Glowa;
    //cout<<"   "<<*Kpom<<endl;
    for(int i=0; i<LK->LKrawedzi; ++i)
    {
        TabPom[0]=Kpom->Poczatek.Wierz;
        TabPom[1]=Kpom->Koniec.Wierz;
        TabPom[2]=Kpom->Waga;
           // cout<<TabPom[0]<<", "<<TabPom[1]<<", "<<TabPom[2]<<"\n";
        macierz[TabPom[0]][TabPom[1]]=TabPom[2];
        macierz[TabPom[1]][TabPom[0]]=TabPom[2];

        Kpom=Kpom->Nastepna;
    }

    //PokazMacierz(macierz, LK->LWierzcholkow);
    delete Kpom;
}


////
void Bellman_FordListaSasiedztwa(ListaKrawedzi *LK, ListaSasiedztwa ** tabList)
{
    ListaSasiedztwa *Sasiedzi;
    int maks_wart_int=2147483647;
    int *KosztDrogi;
    KosztDrogi = new int[LK->LWierzcholkow];
    int *poprzednik;
    poprzednik=new int [LK->LWierzcholkow];
    //cout<<"1\n";
    for(int i=0; i<LK->LWierzcholkow; ++i)
    {
        poprzednik[i]=-1;
        KosztDrogi[i]=maks_wart_int;
    }
    KosztDrogi[LK->startowy]=0;
    for(int i=0; i<LK->LWierzcholkow; ++i)
    { // cout<<i<<" pierwsza petla \n";
        for(int j=0; j<LK->LWierzcholkow; ++j)
        {  // cout<<j<<"druga petla"<<endl;
            for(Sasiedzi=tabList[j]; Sasiedzi; Sasiedzi=Sasiedzi->Nast)
            {
                if(KosztDrogi[j]!=maks_wart_int && KosztDrogi[Sasiedzi->Wierz] > KosztDrogi[j]+Sasiedzi->Waga)
                 {

                    KosztDrogi[Sasiedzi->Wierz]=KosztDrogi[j]+Sasiedzi->Waga;
                poprzednik[Sasiedzi->Wierz]=j;
                }
            //cout<<Sasiedzi->Waga<<endl;
            }
        }
    }
   // for(int i =0; i<sizeof(*poprzednik); i++) cout<<poprzednik[i]<<" "; petla do testu tablicy  drogi

/*cout<<"koszt drogi LS\n";
PokazNajkSciezke(KosztDrogi, poprzednik, LK->LWierzcholkow);*/
}



////
void PokazMacierz(int ** macierz, int wierz)
{
    for(int i=0; i<wierz; ++i)
    {
        for(int j=0; j<wierz; ++j)

            cout<<macierz[i][j]<<" ";
        cout<<"\n";
    }

}




////

void StworzListeSasiedztwa(ListaSasiedztwa** TabList, ListaKrawedzi *LK, ListaSasiedztwa * L)
    {
      //  int a=G->LiczbaWierzcholkow;
        //2 cout<<"0\n<<"<<a;
        int *TabPom = new int[3];
        for(int i=0; i<LK->LWierzcholkow; ++i)
          TabList[i]=NULL;
        Krawedz *Kpom=new Krawedz;

    Kpom=LK->Glowa;
      //cout<<"1 ---- "<<Kpom<<"\n";		//tworzenie listy sasiedztwa
    for(int i=0; i<LK->LKrawedzi; ++i)
    {  // cout<<"TABPOM\n";
        TabPom[0]=Kpom->Poczatek.Wierz;
        TabPom[1]=Kpom->Koniec.Wierz;
        TabPom[2]=Kpom->Waga;
        //cout<<TabPom[0]<<" "<<TabPom[1]<<" "<<TabPom[2]<<"\n";

        //this=new ListaSasiedztwa;
        L= new ListaSasiedztwa;
        L->Wierz=TabPom[1];
        L->Waga=TabPom[2];
        L->Nast=TabList[TabPom[0]];
        TabList[TabPom[0]]=L;
        Kpom=Kpom->Nastepna;
    }
   // cout<<"2\n"; //sprawdzanie dzialania algorytmu // powtarzanie dla grafu nieskierowanego
    Kpom=LK->Glowa;
    for(int j=0; j<LK->LKrawedzi; ++j)
    {
        TabPom[1]=Kpom->Poczatek.Wierz;
        TabPom[0]=Kpom->Koniec.Wierz;
        TabPom[2]=Kpom->Waga;
        //this=new ListaSasiedztwa;
        L= new ListaSasiedztwa;
        L->Wierz=TabPom[1];
        L->Waga=TabPom[2];
        L->Nast=TabList[TabPom[0]];
        TabList[TabPom[0]]=L;
        Kpom=Kpom->Nastepna;
      //  cout>>Kpom->Poczatek.Wierz>>Kpom->Koniec.Wierz;
    }
    //cout<<"3\n"; //sprawdzanie dzialania algorytmu
    delete [] TabPom;
    }



////
void Bellman_FordMacierzSasiedztwa(int **Macierz, ListaKrawedzi *LK)
{   //cout<<LK->LWierzcholkow<<endl;
    int * KosztDrogi=new int[LK->LWierzcholkow];
    int * Poprzedni=new int [LK->LWierzcholkow];
     int maks_wart_int=2147483647;
    for (int i=0; i<LK->LWierzcholkow; ++i)
    {
        KosztDrogi[i]=maks_wart_int;
        Poprzedni[i]=-1;
    }
    KosztDrogi[LK->startowy]=0;
    for(int i=1; i<LK->LWierzcholkow; ++i)
    {
        for(int j=0; j<LK->LWierzcholkow; ++j)
        {
            for(int k=0; k<LK->LWierzcholkow; ++k)
            {
                if(KosztDrogi[j] != maks_wart_int && Macierz[k][j] != 0 && KosztDrogi[k]>KosztDrogi[j]+Macierz[k][j])
                {

                    Poprzedni[k]=j;KosztDrogi[k]=KosztDrogi[j]+Macierz[k][j];
                }
            }
        }
    }
    }



///
void WyswietlListeSasiedztwa(ListaSasiedztwa ** TabList, int Wie)
{
    ListaSasiedztwa *L;
    cout<<"LISTA:\n";
    for(int i=0; i<Wie; i++)
    {
        cout<<"["<<i<<"]: ";
        L=TabList[i];
        while(L)
        {
            cout<<L->Wierz<<", ";
            L=L->Nast;
        }
        cout<<endl;
    }
    delete L;
}


