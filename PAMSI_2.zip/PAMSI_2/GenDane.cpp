#include "GenDane.h"
using namespace std;
void WypiszDaneDoPliku(int LiczbaWierzcholkow, int LiczbaKrawedzi, ofstream & plik)
{
    int PozLiczbaKrawedzi=LiczbaKrawedzi-LiczbaWierzcholkow+1;
    int LicznikWierzcholkow=LiczbaWierzcholkow;
    int Licznik=0;

    plik<<LiczbaKrawedzi<<" "<<LiczbaWierzcholkow<<" "<<rand()%LiczbaWierzcholkow<<" "<<endl;
    int tmp;

    for(int j=0; j<LiczbaWierzcholkow-1 && j<LiczbaKrawedzi-1; ++j)
    {
        plik<<j<<" "<<j+1<<" "<<rand()%50+1<<" "<<endl;
    }

///losowe krawedzie -> losowa waga
    while(Licznik<PozLiczbaKrawedzi)
    {
        tmp=0;
        while(Licznik<PozLiczbaKrawedzi && tmp<LicznikWierzcholkow-2)
        {
            plik<<LicznikWierzcholkow-1<<" "<<tmp<<" "<<rand()%50+1<<" "<<endl;
            tmp++;
            Licznik++;

        }
        LicznikWierzcholkow--;
    }

}

void GenerujDaneGrafow(ofstream& plik)
{
    int w=5,g=4, Test=100; /// zmienne ułatwiające przeprowadzanie testów
    int TabLiczbWierzcholkow[w]={10, 50, 100, 150, 300};
    int TabGestosci[g]={25, 50, 75, 100};
    int TabMaxLiczbyKrawedzi[5];
    int TabLiczbyKrawedzi[5][4];

    plik.open("gen_dane.txt", ios_base::out);



    for(int i=0; i<w; ++i)
    {
        TabMaxLiczbyKrawedzi[i]=((TabLiczbWierzcholkow[i]-1)*TabLiczbWierzcholkow[i])/2;
        for(int j=0; j<g; ++j)
        {
            TabLiczbyKrawedzi[i][j]=(TabGestosci[j]*TabMaxLiczbyKrawedzi[i])/100;
            for(int l=0; l<Test; ++l)
            {
                WypiszDaneDoPliku(TabLiczbWierzcholkow[i], TabLiczbyKrawedzi[i][j], plik);
            }
        }
    } plik.close();
}

